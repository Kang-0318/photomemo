import React from 'react'

const AdminDashboard = () => {
  return (
    <div>adminDashboard</div>
  )
}

export default AdminDashboard